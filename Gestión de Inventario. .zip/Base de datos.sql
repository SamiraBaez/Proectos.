-- Primero ejecute la linea de crear la base de datos sola.
Create database InventarioDB;

-- Ahora puede ejecutar todo lo demas a la vez y podra usar bien el programa de c#.
Use InventarioDB;


Create table Proveedores(
IdProveedor int identity(1,1) primary key,
Empresa varchar(100) unique not null,
Direccion varchar(300) not null,
Telefono varchar(200) not null
);

Create table Categoria(
IdCategoria int identity(1,1) primary key,
Nombre varchar(100) unique not null,
Descripcion varchar(1000) not null
);

Create table Producto (
    Codigo int primary key identity(1,1),
	Nombre varchar(200) not null,
    IdCategoria int not null,
    IdProveedor int not null,
    Precio float not null,
    EnExistencia int not null,

    Constraint FK_Producto_Proveedor FOREIGN KEY (IdProveedor)
        References Proveedores(IdProveedor) ON DELETE CASCADE, 
    Constraint FK_Producto_Categoria FOREIGN KEY (IdCategoria)
        References Categoria(IdCategoria) ON DELETE CASCADE
);

INSERT INTO Proveedores (Empresa, Direccion, Telefono) 
VALUES 
('Tech Supplies Inc.', '1234 Silicon Valley Blvd, California, USA', '555-1234'),
('Electronica Avanzada', 'Av. Insurgentes 456, Ciudad de M�xico, M�xico', '555-6789'),
('Soluciones Industriales', 'Carrera 7 #89-10, Bogot�, Colombia', '555-9876');

INSERT INTO Categoria (Nombre, Descripcion) 
VALUES 
('Electr�nica', 'Componentes y dispositivos electr�nicos como resistencias, capacitores, y transistores.'),
('Herramientas', 'Instrumentos utilizados para construcci�n y mantenimiento de sistemas.'),
('Accesorios', 'Partes y piezas adicionales para mejorar o reparar otros productos.');

INSERT INTO Producto (Nombre, IdCategoria, IdProveedor, Precio, EnExistencia) 
VALUES 
('Resistencia 10k Ohms', 1, 1, 0.10, 500),
('Mult�metro Digital', 2, 2, 25.50, 150),
('Cable USB', 3, 1, 5.00, 300),
('Taladro Inal�mbrico', 2, 3, 60.00, 100),
('Capacitor 100uF', 1, 1, 0.25, 400);
