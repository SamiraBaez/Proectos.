﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using WindowsFormsApp1;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace Gestión_de_Inventario
{
    public partial class FormdeCategorias : Form
    {
        //Hacer Referencia de Base de datos
        private conectdatabase Conectarbase = new conectdatabase();
        //Iniciar Tabla para mostrar
        public FormdeCategorias()
        {
            InitializeComponent();
            Categoria();
        }
        // Crear Funcion para seleccionar todas las categorias y mostrarlas.
        private void Categoria()
        {
            string query = "select * from Categoria";

            using (SqlConnection conn = Conectarbase.Conectar())
            {
                SqlCommand cmd = new SqlCommand(query, conn);
                SqlDataAdapter da = new SqlDataAdapter(cmd);
                DataTable dt = new DataTable();
                da.Fill(dt);
                dataGridView1.DataSource = dt;
            }
        }

        private void FormdeCategorias_Load(object sender, EventArgs e)
        {

        }
        
        //Cerrar Programa
        private void Boton_salir_Click_1(object sender, EventArgs e)
        {
            Close();
        }
        
        //Crear un contenedor del id y Funcion para poner valores del datagrid en los textbox 
        string ContenedorId;
        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0)
            {
                DataGridViewRow row = dataGridView1.Rows[e.RowIndex];
                ContenedorId = row.Cells["IdCategoria"].Value.ToString();
                textBox1.Text = row.Cells["Nombre"].Value.ToString();
                textBox2.Text = row.Cells["Descripcion"].Value.ToString();
            }
        }

        //Boton para agregar categorias por cada clic
        private void Boton_agregar_Click(object sender, EventArgs e)
        {
            string query = "insert into Categoria (Nombre, Descripcion) values (@Nombre, @Descripcion)";

            using (SqlConnection conn = Conectarbase.Conectar())
            {

                try
                {
                    SqlCommand cmd = new SqlCommand(query, conn);
                    cmd.Parameters.AddWithValue("@Nombre", textBox1.Text);
                    cmd.Parameters.AddWithValue("@Descripcion", textBox2.Text);
                    cmd.ExecuteNonQuery();
                    MessageBox.Show("Se agrego la Categoria");
                    Categoria();
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Hubo un error para agregar la categoria: " + ex.Message);
                }
            }
        }

        //Boton para eliminar categorias por cada clic
        private void Boton_eliminar_Click(object sender, EventArgs e)
        {
            string query = "delete from Categoria where IdCategoria = @IdCategoria";

            using (SqlConnection conn = Conectarbase.Conectar())
            {
                SqlCommand cmd = new SqlCommand(query, conn);
                cmd.Parameters.AddWithValue("@IdCategoria", ContenedorId);

                try
                {
                    cmd.ExecuteNonQuery();
                    MessageBox.Show("La Categoria se elimino exitosamente");
                    Categoria();
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Hubo un error al eliminar la categoria: " + ex.Message);
                }
            }
        }

        //Boton para actualizar categorias por cada clic
        private void Boton_Actualizar_Click(object sender, EventArgs e)
        {
            string query = "update Categoria set Nombre = @Nombre, Descripcion = @Descripcion where IdCategoria =  @IdCategoria";

            using (SqlConnection conn = Conectarbase.Conectar())
            {

                try
                {
                    SqlCommand cmd = new SqlCommand(query, conn);
                    cmd.Parameters.AddWithValue("@IdCategoria", ContenedorId);
                    cmd.Parameters.AddWithValue("@Nombre", textBox1.Text);
                    cmd.Parameters.AddWithValue("@Descripcion", textBox2.Text);
                    cmd.ExecuteNonQuery();
                    MessageBox.Show("Se ha actualizado la categoria");
                    Categoria();
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Hubo un error al actualizar la categoria: " + ex.Message);
                }
            }
        }
    }
}
