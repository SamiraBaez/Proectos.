﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using WindowsFormsApp1;

namespace Gestión_de_Inventario
{
    public partial class FormdePedidos : Form
    {
        //Hacer Referencia de Base de datos


        private conectdatabase Conectarbase = new conectdatabase();

        //Iniciar Tabla para mostrar

        public FormdePedidos()
        {
            InitializeComponent();
            Productos();
            Proveedores();
            Categorias();
        }

        //Cargar Productos 
        private void Productos()
        {
            string query = "select p.Codigo, p.Nombre, p.Precio, p.EnExistencia, c.Nombre AS Categoria, pr.Empresa AS Proveedor, p.IdCategoria, p.IdProveedor FROM Producto p JOIN Categoria c ON p.IdCategoria = c.IdCategoria JOIN Proveedores pr ON p.IdProveedor = pr.IdProveedor";
              

            using (SqlConnection conn = Conectarbase.Conectar())
            {
                try
                {
                    SqlDataAdapter da = new SqlDataAdapter(query, conn);
                    DataTable dt = new DataTable();
                    da.Fill(dt);

                    dataGridView1.DataSource = dt;
                    dataGridView1.Columns["IdCategoria"].Visible = false;
                    dataGridView1.Columns["IdProveedor"].Visible = false;
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Hubo un problema al cargar los productos: " + ex.Message);
                }
            }
        }

        //Cargar Proveedores
        private void Proveedores()
        {
            string query = "select IdProveedor, Empresa from Proveedores";

            using (SqlConnection conn = Conectarbase.Conectar())
            {
                try
                {
                    SqlDataAdapter da = new SqlDataAdapter(query, conn);
                    DataTable dt = new DataTable();
                    da.Fill(dt);

                    comboBox2.DataSource = dt;
                    comboBox2.DisplayMember = "Empresa";
                    comboBox2.ValueMember = "IdProveedor"; ;
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Hubo un problema al cargar proveedores: " + ex.Message);
                }
            }
        }

        //Cargar Categorias
        private void Categorias()
        {
            string query = "select IdCategoria, Nombre from Categoria";

            using (SqlConnection conn = Conectarbase.Conectar())
            {
                try
                {
                    SqlDataAdapter da = new SqlDataAdapter(query, conn);
                    DataTable dt = new DataTable();
                    da.Fill(dt);

                    comboBox1.DataSource = dt;
                    comboBox1.DisplayMember = "Nombre";
                    comboBox1.ValueMember = "IdCategoria"; ;
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Hubo un problema al cargar categorias: " + ex.Message);
                }
            }
        }
        private void FormdePedidos_Load(object sender, EventArgs e)
        {

        }

        //Crear un contenedor del id y Funcion para poner valores del datagrid en los textbox 

        string ContenedorId;
        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0)
            {
                DataGridViewRow row = dataGridView1.Rows[e.RowIndex];
                ContenedorId = row.Cells["Codigo"].Value.ToString();
                textBox1.Text = row.Cells["Nombre"].Value.ToString();
                textBox2.Text = row.Cells["Precio"].Value.ToString();
                textBox3.Text = row.Cells["EnExistencia"].Value.ToString();
                comboBox1.SelectedValue = row.Cells["IdCategoria"].Value;
                comboBox2.SelectedValue = row.Cells["IdProveedor"].Value;
            }
        }


        //Boton para actualizar Productos por cada clic

        private void Boton_Actualizar_Click(object sender, EventArgs e)
        {
            string query = "update Producto set Nombre = @Nombre, IdProveedor = @IdProveedor, IdCategoria = @IdCategoria, Precio = @Precio, EnExistencia = @EnExistencia where Codigo = @Codigo";

            using (SqlConnection conn = Conectarbase.Conectar())
            {

                try
                {
                    SqlCommand cmd = new SqlCommand(query, conn);
                    cmd.Parameters.AddWithValue("@Codigo", ContenedorId);
                    cmd.Parameters.AddWithValue("@Nombre", textBox1.Text);
                    cmd.Parameters.AddWithValue("@Precio", textBox2.Text);
                    cmd.Parameters.AddWithValue("@EnExistencia", textBox3.Text);
                    cmd.Parameters.AddWithValue("@IdCategoria", comboBox1.SelectedValue);
                    cmd.Parameters.AddWithValue("@IdProveedor", comboBox2.SelectedValue);

                    cmd.ExecuteNonQuery();
                    MessageBox.Show("Se ha actualizado el producto");
                    Productos();
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Hubo un error al actualizar el producto: " + ex.Message);
                }
            }
        }

        //Boton para agregar Productos por cada clic
        private void Boton_agregar_Click(object sender, EventArgs e)
        {
            string query = "insert into Producto (Nombre, IdProveedor, IdCategoria, Precio, EnExistencia) values (@Nombre, @IdProveedor, @IdCategoria, @Precio, @EnExistencia)";

            using (SqlConnection conn = Conectarbase.Conectar())
            {

                try
                {
                    SqlCommand cmd = new SqlCommand(query, conn);
                    cmd.Parameters.AddWithValue("@Nombre", textBox1.Text);
                    cmd.Parameters.AddWithValue("@Precio", textBox2.Text);
                    cmd.Parameters.AddWithValue("@EnExistencia", textBox3.Text);
                    cmd.Parameters.AddWithValue("@IdCategoria", comboBox1.SelectedValue);
                    cmd.Parameters.AddWithValue("@IdProveedor", comboBox2.SelectedValue);

                    cmd.ExecuteNonQuery();
                    MessageBox.Show("Se agrego el Producto");
                    Productos();
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Hubo un error para agregar al producto: " + ex.Message);
                }
            }
        }


        //Boton para eliminar Productos por cada clic
        private void Boton_eliminar_Click(object sender, EventArgs e)
        {
            string query = "delete from Producto where Codigo = @Codigo";

            using (SqlConnection conn = Conectarbase.Conectar())
            {
                SqlCommand cmd = new SqlCommand(query, conn);
                cmd.Parameters.AddWithValue("@Codigo", ContenedorId);

                try
                {
                    cmd.ExecuteNonQuery();
                    MessageBox.Show("El producto se elimino exitosamente");
                    Productos();
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Hubo un error al eliminar el producto: " + ex.Message);
                }
            }
        }

        //Boton para terminar
        private void Boton_salir_Click(object sender, EventArgs e)
        {
            Close();
        }
    }
}
