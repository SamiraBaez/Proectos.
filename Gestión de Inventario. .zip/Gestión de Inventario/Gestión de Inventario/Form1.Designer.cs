﻿namespace Gestión_de_Inventario
{
    partial class Form1
    {
        /// <summary>
        /// Variable del diseñador necesaria.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpiar los recursos que se estén usando.
        /// </summary>
        /// <param name="disposing">true si los recursos administrados se deben desechar; false en caso contrario.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código generado por el Diseñador de Windows Forms

        /// <summary>
        /// Método necesario para admitir el Diseñador. No se puede modificar
        /// el contenido de este método con el editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.Boton_Cierre = new System.Windows.Forms.Button();
            this.Boton_Consultas = new System.Windows.Forms.Button();
            this.Boton_Productos = new System.Windows.Forms.Button();
            this.Boton_Categorias = new System.Windows.Forms.Button();
            this.Boton_Proveedores = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // Boton_Cierre
            // 
            this.Boton_Cierre.Location = new System.Drawing.Point(316, 328);
            this.Boton_Cierre.Name = "Boton_Cierre";
            this.Boton_Cierre.Size = new System.Drawing.Size(178, 47);
            this.Boton_Cierre.TabIndex = 11;
            this.Boton_Cierre.Text = "Cerrar";
            this.Boton_Cierre.UseVisualStyleBackColor = true;
            this.Boton_Cierre.Click += new System.EventHandler(this.Boton_Cierre_Click);
            // 
            // Boton_Consultas
            // 
            this.Boton_Consultas.Location = new System.Drawing.Point(31, 308);
            this.Boton_Consultas.Name = "Boton_Consultas";
            this.Boton_Consultas.Size = new System.Drawing.Size(221, 86);
            this.Boton_Consultas.TabIndex = 10;
            this.Boton_Consultas.Text = "Reportes";
            this.Boton_Consultas.UseVisualStyleBackColor = true;
            this.Boton_Consultas.Click += new System.EventHandler(this.Boton_Consultas_Click);
            // 
            // Boton_Productos
            // 
            this.Boton_Productos.Location = new System.Drawing.Point(551, 308);
            this.Boton_Productos.Name = "Boton_Productos";
            this.Boton_Productos.Size = new System.Drawing.Size(221, 86);
            this.Boton_Productos.TabIndex = 9;
            this.Boton_Productos.Text = "Producto";
            this.Boton_Productos.UseVisualStyleBackColor = true;
            this.Boton_Productos.Click += new System.EventHandler(this.Boton_Pedidos_Click);
            // 
            // Boton_Categorias
            // 
            this.Boton_Categorias.Location = new System.Drawing.Point(551, 47);
            this.Boton_Categorias.Name = "Boton_Categorias";
            this.Boton_Categorias.Size = new System.Drawing.Size(221, 86);
            this.Boton_Categorias.TabIndex = 8;
            this.Boton_Categorias.Text = "Categorias";
            this.Boton_Categorias.UseVisualStyleBackColor = true;
            this.Boton_Categorias.Click += new System.EventHandler(this.Boton_Categorias_Click);
            // 
            // Boton_Proveedores
            // 
            this.Boton_Proveedores.Location = new System.Drawing.Point(31, 47);
            this.Boton_Proveedores.Name = "Boton_Proveedores";
            this.Boton_Proveedores.Size = new System.Drawing.Size(221, 86);
            this.Boton_Proveedores.TabIndex = 7;
            this.Boton_Proveedores.Text = "Proveedores";
            this.Boton_Proveedores.UseVisualStyleBackColor = true;
            this.Boton_Proveedores.Click += new System.EventHandler(this.Boton_Proveedores_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 36F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(229, 147);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(335, 138);
            this.label1.TabIndex = 6;
            this.label1.Text = "Gestión de \r\nInventario";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.Boton_Cierre);
            this.Controls.Add(this.Boton_Consultas);
            this.Controls.Add(this.Boton_Productos);
            this.Controls.Add(this.Boton_Categorias);
            this.Controls.Add(this.Boton_Proveedores);
            this.Controls.Add(this.label1);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button Boton_Cierre;
        private System.Windows.Forms.Button Boton_Consultas;
        private System.Windows.Forms.Button Boton_Productos;
        private System.Windows.Forms.Button Boton_Categorias;
        private System.Windows.Forms.Button Boton_Proveedores;
        private System.Windows.Forms.Label label1;
    }
}

