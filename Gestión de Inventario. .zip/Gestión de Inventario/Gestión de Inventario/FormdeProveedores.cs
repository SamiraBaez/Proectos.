﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using WindowsFormsApp1;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace Gestión_de_Inventario
{
    public partial class FormdeProveedores : Form
    {

        //Hacer Referencia de Base de datos

        private conectdatabase Conectarbase = new conectdatabase();
        //Iniciar Tabla para mostrar

        public FormdeProveedores()
        {
            InitializeComponent();
            Proveedores();
        }

        private void FormdeProveedores_Load(object sender, EventArgs e)
        {

        }
        // Crear Funcion para seleccionar todas los proveedores y mostrarlas.

        private void Proveedores()
        {
            string query = "select * from Proveedores";

            using (SqlConnection conn = Conectarbase.Conectar())
            {
                SqlCommand cmd = new SqlCommand(query, conn);
                SqlDataAdapter da = new SqlDataAdapter(cmd);
                DataTable dt = new DataTable();
                da.Fill(dt);
                dataGridView1.DataSource = dt;
            }
        }
        //Crear un contenedor del id y Funcion para poner valores del datagrid en los textbox 

        string ContenedorId;
        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0)
            {
                DataGridViewRow row = dataGridView1.Rows[e.RowIndex];
                ContenedorId = row.Cells["IdProveedor"].Value.ToString();
                textBox1.Text = row.Cells["Empresa"].Value.ToString();
                textBox2.Text = row.Cells["Direccion"].Value.ToString();
                textBox3.Text = row.Cells["Telefono"].Value.ToString();
            }
        }
        //Boton para cerrar
        private void Boton_salir_Click(object sender, EventArgs e)
        {
            Close();
        }

        //Boton para eliminar proveedores por cada clic

        private void Boton_eliminar_Click(object sender, EventArgs e)
        {
            string query = "delete from Proveedores where IdProveedor = @IdProveedor";

            using (SqlConnection conn = Conectarbase.Conectar())
            {
                SqlCommand cmd = new SqlCommand(query, conn);
                cmd.Parameters.AddWithValue("@IdProveedor", ContenedorId);

                try
                {
                    cmd.ExecuteNonQuery();
                    MessageBox.Show("El proveedor se elimino exitosamente");
                    Proveedores();
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Hubo un error al eliminar el proveedor: " + ex.Message);
                }
            }
        }

        //Boton para agregar proveedores por cada clic

        private void Boton_agregar_Click(object sender, EventArgs e)
        {
            string query = "insert into Proveedores (Empresa, Telefono, Direccion) values (@Empresa, @Telefono, @Direccion)";

            using (SqlConnection conn = Conectarbase.Conectar())
            {

                try
                {
                    SqlCommand cmd = new SqlCommand(query, conn);
                    cmd.Parameters.AddWithValue("@Empresa", textBox1.Text);
                    cmd.Parameters.AddWithValue("@Telefono", textBox2.Text);
                    cmd.Parameters.AddWithValue("@Direccion", textBox3.Text);

                    cmd.ExecuteNonQuery();
                    MessageBox.Show("Se agrego el Proveedor");
                    Proveedores();
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Hubo un error para agregar al proveedor: " + ex.Message);
                }
            }
        }

        //Boton para actualizar proveedores por cada clic

        private void Boton_Actualizar_Click(object sender, EventArgs e)
        {
            string query = "update Proveedores set Empresa = @Empresa, Telefono = @Telefono, Direccion = @Direccion where IdProveedor = @IdProveedor";

            using (SqlConnection conn = Conectarbase.Conectar())
            {

                try
                {
                    SqlCommand cmd = new SqlCommand(query, conn);
                    cmd.Parameters.AddWithValue("@IdProveedor", ContenedorId);
                    cmd.Parameters.AddWithValue("@Empresa", textBox1.Text);
                    cmd.Parameters.AddWithValue("@Telefono", textBox2.Text);
                    cmd.Parameters.AddWithValue("@Direccion", textBox3.Text);

                    cmd.ExecuteNonQuery();
                    MessageBox.Show("Se ha actualizado el proveedor");
                    Proveedores();
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Hubo un error al actualizar el proveedor: " + ex.Message);
                }
            }
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }
    }
}
