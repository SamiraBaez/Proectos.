﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using WindowsFormsApp1;

namespace Gestión_de_Inventario
{
    public partial class FormparaConsultas : Form
    {
        //Hacer Referencia de Base de datos

        private conectdatabase Conectarbase = new conectdatabase();

        //Iniciar Tabla para mostrar

        public FormparaConsultas()
        {
            InitializeComponent();
            Proveedores();
            Categorias();
            Reporte();
            Consulta();
        }

        //Cargar Proveedores
        private void Proveedores()
        {
            string query = "select IdProveedor, Empresa from Proveedores";

            using (SqlConnection conn = Conectarbase.Conectar())
            {
                try
                {
                    SqlDataAdapter da = new SqlDataAdapter(query, conn);
                    DataTable dt = new DataTable();
                    da.Fill(dt);

                    comboBox2.DataSource = dt;
                    comboBox2.DisplayMember = "Empresa";
                    comboBox2.ValueMember = "IdProveedor"; ;
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Hubo un problema al cargar proveedores: " + ex.Message);
                }
            }
        }

        //Cargar Categorias

        private void Categorias()
        {
            string query = "select IdCategoria, Nombre from Categoria";

            using (SqlConnection conn = Conectarbase.Conectar())
            {
                try
                {
                    SqlDataAdapter da = new SqlDataAdapter(query, conn);
                    DataTable dt = new DataTable();
                    da.Fill(dt);

                    comboBox1.DataSource = dt;
                    comboBox1.DisplayMember = "Nombre";
                    comboBox1.ValueMember = "IdCategoria"; ;
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Hubo un problema al cargar categorias: " + ex.Message);
                }
            }
        }

        //Cargar Consulta

        private void Consulta()
        {
            string query = "select p.Codigo, p.Nombre, p.Precio, p.EnExistencia, c.Nombre AS Categoria, pr.Empresa AS Proveedor, p.IdCategoria, p.IdProveedor FROM Producto p JOIN Categoria c ON p.IdCategoria = c.IdCategoria JOIN Proveedores pr ON p.IdProveedor = pr.IdProveedor where P.IdCategoria = @IdCategoria and P.IdProveedor = @IdProveedor ";

            using (SqlConnection conn = Conectarbase.Conectar())
            {
                SqlCommand cmd = new SqlCommand(query, conn);
                cmd.Parameters.AddWithValue("@IdCategoria", comboBox1.SelectedValue);
                cmd.Parameters.AddWithValue("@IdProveedor", comboBox2.SelectedValue);
                SqlDataAdapter da = new SqlDataAdapter(cmd);
                DataTable dt = new DataTable();
                da.Fill(dt);
                
                dataGridView1.DataSource = dt;
                try
                {

                }
                catch (Exception)
                {
                    MessageBox.Show("Primero debe existir Proveedores y Categorias: ");
                }
            }
        }

        //Cargar Reporte con select especificos para mostrar la informacion deseada.

        private void Reporte()
        {
            string query = "select p.Codigo, p.Nombre, p.Precio, p.EnExistencia, c.Nombre AS Categoria, pr.Empresa AS Proveedor, p.IdCategoria, p.IdProveedor FROM Producto p JOIN Categoria c ON p.IdCategoria = c.IdCategoria JOIN Proveedores pr ON p.IdProveedor = pr.IdProveedor where EnExistencia <10 ";

            using (SqlConnection conn = Conectarbase.Conectar())
            {
                SqlCommand cmd = new SqlCommand(query, conn);
                SqlDataAdapter da = new SqlDataAdapter(cmd);
                DataTable dt = new DataTable();
                da.Fill(dt);

                dataGridView2.DataSource = dt;
                try
                {

                }
                catch (Exception)
                {
                    MessageBox.Show("Primero debe existir Proveedores y Categorias: ");
                }
            }
        }



        private void FormparaConsultas_Load(object sender, EventArgs e)
        {

        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        //Cargar Consulta despues de especificar la informacion deseada

        private void button1_Click(object sender, EventArgs e)
        {
            Consulta();
        }

        //Boton para salir
        private void button2_Click(object sender, EventArgs e)
        {
            Close(); 
        }
    }
}
