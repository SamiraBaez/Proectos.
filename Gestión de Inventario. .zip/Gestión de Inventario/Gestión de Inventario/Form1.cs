﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Gestión_de_Inventario
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        // Botones para abrir formularios de proveedores, categorias, consultas y pedidos al hacerles clic.
        private void Boton_Proveedores_Click(object sender, EventArgs e)
        {
            FormdeProveedores formproveedor = new FormdeProveedores();
            formproveedor.Show();
        }

        private void Boton_Categorias_Click(object sender, EventArgs e)
        {
            FormdeCategorias formcategoria = new FormdeCategorias();
            formcategoria.Show();
        }

        private void Boton_Consultas_Click(object sender, EventArgs e)
        {
            FormparaConsultas formconsultas = new FormparaConsultas();
            formconsultas.Show();
        }

        private void Boton_Pedidos_Click(object sender, EventArgs e)
        {
            FormdePedidos formpedido = new FormdePedidos();
            formpedido.Show();
        }

        //Cerrar Programa
        private void Boton_Cierre_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }
    }
}
